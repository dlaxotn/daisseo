	function checkErrCode(){
		var errCode = "${errCode}";
		if(errCode != null || errCode != ""){
			switch (errCode) {
			case "1":
				alert("금액이 부족합니다.!");
				location.href = "cartlist";
				break;
			case "2":
				alert("주문이 완료되었습니다.");
				location.href = "cartlist";
				break;


			}
		}
	}

    function comma(num){
        var len, point, str; 
           
        num = num + ""; 
        point = num.length % 3 ;
        len = num.length; 
       
        str = num.substring(0, point); 
        while (point < len) { 
            if (str != "") str += ","; 
            str += num.substring(point, point + 3); 
            point += 3; 
        }     
        return str;
    }
    
    
        function itemSum(){
           var str = "";
           var sum = 0;
           var test  = 0;
           var count = $(".chBox").length;
           for(var i=0; i < count; i++ ){
               if( $(".chBox")[i].checked == true ){
                sum += parseInt($(".chBox")[i].value);
                
               }
           }
           $("#total_sum").html(comma(sum)+" 원");
           $("#amount").val(sum);

        }
        
    	$("#allCheck").click(function(){
    		 var chk = $("#allCheck").prop("checked");
    		 if(chk) {
    		  $(".chBox").prop("checked", true);
    		  itemSum();
    		 } else {
    		  $(".chBox").prop("checked", false);
    		  itemSum();
    		 }
    		});
    	
    	 $(".selectDelete_btn").click(function(){
    		  var confirm_val = confirm("정말 삭제하시겠습니까?");
    		  
    		  if(confirm_val) {

    		   var checkArr = new Array();
    		   
    		   $("input[class='chBox']:checked").each(function(){
    		    checkArr.push($(this).attr("data-basNum"));
    		   });
    		   
    		   if(checkArr == null || checkArr ==0){
    			   alert("삭제할 것을 선택하기 바랍니다.");
    		   }
    		   
    			$.ajax({
    			   url : "deletecart",
    			   type : "post",
    			   dataType: "json",
    			   data : {chBox : checkArr},
    			   success : function(result){
    			    if(result == 1) {          
    			    	alert("삭제완료")
    			     location.href = "cartlist";
    			    } else {
    			     alert("삭제 실패");
    			    }
    			   }
    			  });
    		  }
    		 });
    	 
    	 
    	 $(".chBox").click(function(){
    		  $("#allCheck").prop("checked", false);
    		 }); 
    	 
    	 
    	 
    	  $(".delete_15_btn").click(function(){
    		   var confirm_val = confirm("정말 삭제하시겠습니까?");
    		   
    		   if(confirm_val) {
    		    var checkArr = new Array();
    		    
    		    checkArr.push($(this).attr("data-basNum"));
    		    
    		    $.ajax({
    		     url : "deletecart",
    		     type : "post",
    			 dataType: "json",
    		     data : {chBox : checkArr},
    		     success : function(result){
    		      if(result == 1) {     
    		       location.href = "cartlist";
    		      } else {
    		       alert("삭제 실패");
    		      }
    		     }
    		    });
    		   } 
    		  });
    	  
    	  

          $("#orderSuccess").click(function() {
              var checkArr = new Array();
              
              //checked 되어있는 row에 data-bas 속성 값을 가져와 Array에 넣어준다. 
              $("input[class='chBox']:checked").each(function () {
                  checkArr.push($(this).attr("data-basNum"));
              });
              
              if(checkArr == null || checkArr ==0){
            	   alert("주문할 것을 체크하시기 바랍니다.");
               }else {
                     

              //input hidden으로 되어있는 id가 chk에 배열을 넣어준다.
              //넣어주면 chk[]이름으로 controller에 넘어가 method에서 @RequestParam으로 받기만 해주면 된다.
              //Param으로는 안된다.

              $("#chk").val(checkArr); //

              if (confirm("주문완료 하시겠습니까?")) {
                  $("#orderForm").submit();
              }
               }

          });