package com.dla.daisseo.mapper;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.dla.daisseo.model.ListVo;
import com.dla.daisseo.model.Project_daVo;
import com.dla.daisseo.model.Project_join_daVo;
import com.dla.daisseo.model.Review_daVo;
import com.dla.daisseo.model.SearchVO;
import com.dla.daisseo.model.Shopping_basket_daVo;
import com.dla.daisseo.model.type_daVo;


@Mapper
public interface ProductMapper {
	
	int insertProduct(Project_daVo product) throws Exception;
	//��ǰ���ε�
	
	List<Project_daVo> list() throws Exception;
	//�α��ǰ����Ʈ
	 
	List<Project_daVo> newprolist() throws Exception;
	 
	List<Project_daVo> reviewprolist() throws Exception;
	 
	Project_daVo productcontent(int proj_num) throws Exception;
	//��ǰ ����
	 
	int addCart(Shopping_basket_daVo cart) throws Exception;
	 
	 
	int contentOrder(Project_join_daVo order) throws Exception;
	 
	List<Project_daVo> sublist(@Param("search") String search, @Param("typ_num") int typ_num) throws Exception;
	 //�������
	 
	type_daVo typelist(int typ_num) throws Exception;
	 
	int writerReview(Review_daVo review_da) throws Exception;
	 
			
	int orderSelect(@Param("mem_id") String mem_id, @Param("proj_num") int proj_num) throws Exception;
	
	int reviewDel(int review_num) throws Exception;
	
	
	int productupid(Project_daVo projectdavo) throws Exception;
	
	int productDel(int proj_num) throws Exception;

	int reviewConfirm(Review_daVo reviewdavo) throws Exception;
	
	String reviewnum(Review_daVo reviewdavo) throws Exception;

}
