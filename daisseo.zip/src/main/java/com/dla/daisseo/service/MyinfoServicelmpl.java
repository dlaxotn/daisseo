package com.dla.daisseo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dla.daisseo.mapper.MyinfoMapper;
import com.dla.daisseo.mapper.ProductMapper;
import com.dla.daisseo.model.Career_daVo;
import com.dla.daisseo.model.ListVo;
import com.dla.daisseo.model.Member_daVo;
import com.dla.daisseo.model.Project_daVo;
import com.dla.daisseo.model.Project_join_daVo;
import com.dla.daisseo.model.SearchVO;
import com.dla.daisseo.model.Shopping_basket_daVo;
import com.dla.daisseo.model.Shopping_orderVo;

@Service
public class MyinfoServicelmpl implements MyinfoService {
	
	@Autowired
	private MyinfoMapper myinfomapper;
	
	@Autowired
	com.dla.daisseo.utills.PageHelper pageHelper;
	
	// ��������
	@Autowired
	private ProductService productservice; 
	
	@Override
	public List<Shopping_basket_daVo> cartList(String mem_id) throws Exception{
		return this.myinfomapper.cartList(mem_id);
	}


	@Override
	public int deleteCart(Shopping_basket_daVo cart)throws Exception {
		return this.myinfomapper.deleteCart(cart);
	}


	@Override
	public int cartlistorder(Project_join_daVo order)throws Exception {
		return this.myinfomapper.cartlistorder(order);
	}

	@Override
	public Shopping_orderVo ShoppingOrder(int bas_num) throws Exception{
		return this.myinfomapper.ShoppingOrder(bas_num);
	}

	@Override
	  public StringBuffer getPageUrl(ListVo listvo) throws Exception{
		int totalRow = myinfomapper.getTotalRow(listvo);
		return pageHelper.getPageUrl(listvo, totalRow);
	}

	@Override
	public List<ListVo> list(ListVo ListVo) throws Exception{
	    int currentPage = ListVo.getPage();
	    int startRow = (currentPage - 1) * this.pageHelper.getPageSize()+1;
	    int endRow   = currentPage * this.pageHelper.getPageSize(); 
	    ListVo.setStartRow(startRow);
	    ListVo.setEndRow(endRow);
		return this.myinfomapper.list(ListVo);
	}

	@Override
	public int getTotalRow(ListVo ListVo)throws Exception {
		return this.myinfomapper.getTotalRow(ListVo);
	}


	@Override
	public int deliveryUpdate(Project_join_daVo project_join_da)throws Exception {
		return this.myinfomapper.deliveryUpdate(project_join_da);
	}


	@Override
	public int productCountUpdate(Project_daVo project_davo) throws Exception{
		return this.myinfomapper.productCountUpdate(project_davo);
	}


	@Override
	public int permission(Career_daVo career) throws Exception{
		return this.myinfomapper.permission(career);
	}


	@Override
	public List<Member_daVo> permissionmember() throws Exception{
		return this.myinfomapper.permissionmember();
	}


	@Override
	public List<Career_daVo> permissionupdateform(String mem_id) throws Exception{
		return (List<Career_daVo>) this.myinfomapper.permissionupdateform(mem_id);
	}


	@Override
	public int permissionok(String mem_id) throws Exception{
		return this.myinfomapper.permissionok(mem_id);
	}


	@Override
	public int permissionfail(String mem_id) throws Exception{
		return this.myinfomapper.permissionfail(mem_id);
	}


	@Override
	public int permissionupdate(String mem_id) throws Exception{
		System.out.println("����"+mem_id);
		return this.myinfomapper.permissionupdate(mem_id);
	}


	@Override
	public String mem_ok(String mem_id) throws Exception{
		return this.myinfomapper.mem_ok(mem_id);
	}


	@Override
	public int memberDel(String mem_id) throws Exception{
		System.out.println("����"+mem_id);
		return this.myinfomapper.memberDel(mem_id);
	}


	@Override
	public String passokConfirm(String mem_id) throws Exception{
		System.out.print("����"+mem_id);
		return this.myinfomapper.passokConfirm(mem_id);
	}


	@Override
	public Member_daVo myinfoform(String mem_id) throws Exception{
		return this.myinfomapper.myinfoform(mem_id);
	}


	@Override
	public int myinfoupdate(Member_daVo memberdavo) throws Exception{
		return this.myinfomapper.myinfoupdate(memberdavo);
	}

	
}