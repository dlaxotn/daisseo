package com.dla.daisseo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dla.daisseo.mapper.MemberMapper;
import com.dla.daisseo.mapper.ProductMapper;
import com.dla.daisseo.model.ListVo;
import com.dla.daisseo.model.Project_daVo;
import com.dla.daisseo.model.Project_join_daVo;
import com.dla.daisseo.model.Review_daVo;
import com.dla.daisseo.model.SearchVO;
import com.dla.daisseo.model.Shopping_basket_daVo;
import com.dla.daisseo.model.type_daVo;

@Service(value = "productservice")
public class ProductServicelmpl implements ProductService {
	
	@Autowired
	private ProductMapper productmapper;
	
	@Autowired
	com.dla.daisseo.utills.PageHelper pageHelper;


	@Override
	public int insertProduct(Project_daVo product) throws Exception{
		return this.productmapper.insertProduct(product);
	}

	@Override
	public List<Project_daVo> list() throws Exception{
		return this.productmapper.list();
	}
	@Override
	public Project_daVo productcontent(int proj_num) throws Exception{
		return this.productmapper.productcontent(proj_num);
	}

	@Override
	public int addCart(Shopping_basket_daVo cart) throws Exception{
		return this.productmapper.addCart(cart);
	}

	@Override
	public int contentOrder(Project_join_daVo order) throws Exception{
		return this.productmapper.contentOrder(order);
	}

	@Override
	public List<Project_daVo> newprolist() throws Exception{
		return this.productmapper.newprolist();
	}

	@Override
	public List<Project_daVo> reviewprolist() throws Exception{
		return this.productmapper.reviewprolist();
	}

	@Override
	public List<Project_daVo> sublist(String search, int typ_num) throws Exception{
		return this.productmapper.sublist(search, typ_num);
	}

	@Override
	public type_daVo typelist(int typ_num) throws Exception{
		return this.productmapper.typelist(typ_num);
	}

	@Override
	public int writerReview(Review_daVo review_da) throws Exception{
		return this.productmapper.writerReview(review_da);
	}
	

	@Override
	public int reviewDel(int review_num) throws Exception{
		return this.productmapper.reviewDel(review_num);
	}

	@Override
	public int orderSelect(String mem_id, int proj_num) throws Exception{
		return this.productmapper.orderSelect(mem_id, proj_num);
	}


	@Override
	public int productDel(int proj_num) throws Exception{
		return this.productmapper.productDel(proj_num);
	}

	@Override
	public int productupid(Project_daVo projectdavo) throws Exception{
		return this.productmapper.productupid(projectdavo);
	}

	@Override
	public int reviewConfirm(Review_daVo reviewdavo) throws Exception{
		return this.productmapper.reviewConfirm(reviewdavo);
	}

	@Override
	public String reviewnum(Review_daVo reviewdavo) throws Exception {
		return this.productmapper.reviewnum(reviewdavo);
	}

	

}
