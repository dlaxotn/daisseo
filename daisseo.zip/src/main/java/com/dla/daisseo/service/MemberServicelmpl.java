package com.dla.daisseo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dla.daisseo.mapper.MemberMapper;
import com.dla.daisseo.model.Member_daVo;

@Service(value = "memberservice")
public class MemberServicelmpl implements MemberService {
	
	@Autowired
	private MemberMapper memberMapper;
	
	

	@Override
	public int insertMember(Member_daVo member_davo) throws Exception{
		return memberMapper.insertMember(member_davo);
	  
	}
	
	@Override
	public Member_daVo getMember(String mem_id) throws Exception{
		return memberMapper.getMember(mem_id);
		
	}

	@Override
	public Member_daVo findId(Member_daVo member_davo) throws Exception{
		return memberMapper.findId(member_davo);
	}

	@Override
	public Member_daVo findPwd(Member_daVo member_davo) throws Exception{
		return memberMapper.findPwd(member_davo);
	}

	@Override
	public int pwdUpdate(Member_daVo member_davo) throws Exception{
		return memberMapper.pwdUpdate(member_davo);
	}

	@Override
	public Member_daVo pointSelect(String mem_id) throws Exception{
		return memberMapper.pointSelect(mem_id);
	}

	@Override
	public int pointupdate(Member_daVo member_davo) throws Exception{
		return memberMapper.pointupdate(member_davo);
	}

	@Override
	public Member_daVo getmylename(int myle_num) throws Exception{
		return memberMapper.getmylename(myle_num);
	}

}
