/*
package com.dla.daisseo.interceptor;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class SessionInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		PrintWriter out = response.getWriter();

		Object mem_id = request.getSession().getAttribute("mem_id");
		
//		if (request.getRequestURI().equals("/daisseo/member/login")
				//|| request.getRequestURI().equals("/daisseo/product/productupload"))
		//{
//			if (mem_id != null) {
				//response.sendRedirect(request.getContextPath() + "/");
				//return true; // ����
			//} else {
//				return true; // login.do ����
			//}
		//}
		
		
		
		if(mem_id == null){     
            //out.print("<script>alert('������ �����ϴ�.');</script>");
		    response.sendRedirect(request.getContextPath() + "/member/login");
            //out.flush();
		    return false; 
		} 
		else {
		    return true; //���� URL ������ ����
		}
		   }

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
	}
}
*/
