package com.dla.daisseo.model;

import java.sql.Date;

public class SearchVO {
	private String type = "";
	private String keyword = "";
	private int   page = 1;
	private int   startRow = 1;
	private int   endRow = 1;
	
	///////////////////////////////////
	// ������� ���� VO
	private int typ_num;
	private String search;
	///////////////////////////////////
	// review ��۰���
	private int proj_num;
//////////////////////////////////////
	//��ǰ �Ǹ� ����
	private String mem_id;

////////////////////////////////////
	private String tableName;
	// �������� �ɰ���
////////////////////////////////////
	private Date review_jdate;
	
	
	
	public Date getProj_jdate() {
		return review_jdate;
	}
	public void setProj_jdate(Date review_jdate) {
		this.review_jdate = review_jdate;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getTyp_num() {
		return typ_num;
	}
	public int getProj_num() {
		return proj_num;
	}
	public void setProj_num(int proj_num) {
		this.proj_num = proj_num;
	}
	public void setTyp_num(int typ_num) {
		this.typ_num = typ_num;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getStartRow() {
		return startRow;
	}
	public void setStartRow(int startRow) {
		this.startRow = startRow;
	}
	public int getEndRow() {
		return endRow;
	}
	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}
	
	


}
