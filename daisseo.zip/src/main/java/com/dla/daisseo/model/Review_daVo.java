package com.dla.daisseo.model;

public class Review_daVo {
	
	private int review_num;
	private String mem_id;
	private int proj_num;
	private String review_content;
	private int star;
	// ���� ����ۼ�
	private int review_star;
	// ���� list 
	private String review_jdate;
	
	public int getStar() {
		return star;
	}
	public int getReview_star() {
		return review_star;
	}
	public void setReview_star(int review_star) {
		this.review_star = review_star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	public int getReview_num() {
		return review_num;
	}
	public void setReview_num(int review_num) {
		this.review_num = review_num;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getProj_num() {
		return proj_num;
	}
	public void setProj_num(int proj_num) {
		this.proj_num = proj_num;
	}
	public String getReview_content() {
		return review_content;
	}
	public void setReview_content(String review_content) {
		this.review_content = review_content;
	}

	public String getReview_jdate() {
		return review_jdate;
	}
	public void setReview_jdate(String review_jdate) {
		this.review_jdate = review_jdate;
	}
	

}
