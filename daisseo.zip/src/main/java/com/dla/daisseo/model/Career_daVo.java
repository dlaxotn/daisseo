package com.dla.daisseo.model;

import java.sql.Date;

import org.hibernate.validator.constraints.NotEmpty;

public class Career_daVo {
	
	private int car_num;

	private String mem_id;
	
	@NotEmpty(message = "�������� �Է��ϼ���.")
	private String car_sdate;
	
	@NotEmpty(message = "������ ���� �Է��ϼ���.")
	private String car_fdate;
	@NotEmpty(message = "������� �Է��ϼ���.")
	private String car_org;
	@NotEmpty(message = "Ȱ�� ������ �Է��ϼ���.")
	private String car_act;

	
	
	public int getCar_num() {
		return car_num;
	}
	public void setCar_num(int car_num) {
		this.car_num = car_num;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getCar_sdate() {
		return car_sdate;
	}
	public void setCar_sdate(String car_sdate) {
		this.car_sdate = car_sdate;
	}
	public String getCar_fdate() {
		return car_fdate;
	}
	public void setCar_fdate(String car_fdate) {
		this.car_fdate = car_fdate;
	}
	public String getCar_org() {
		return car_org;
	}
	public void setCar_org(String car_org) {
		this.car_org = car_org;
	}
	public String getCar_act() {
		return car_act;
	}
	public void setCar_act(String car_act) {
		this.car_act = car_act;
	}
	

}
