package com.dla.daisseo.model;

public class Shopping_orderVo {

	
	private int proj_num;
	private int bas_count;
	private int join_amount; //����*��ǰ�ݾ�+��ۺ�
	
	
	public int getProj_num() {
		return proj_num;
	}
	public void setProj_num(int proj_num) {
		this.proj_num = proj_num;
	}
	public int getBas_count() {
		return bas_count;
	}
	public void setBas_count(int bas_count) {
		this.bas_count = bas_count;
	}
	public int getJoin_amount() {
		return join_amount;
	}
	public void setJoin_amount(int join_amount) {
		this.join_amount = join_amount;
	}

}
