package com.dla.daisseo.model;

import java.sql.Date;

///////////////////////////////////// LIST ���� ������ ���� �� ������ ó���� �ϳ��ϳ� DAO �� �����
public class ListVo {
	
	private String mem_id; //���̵�
	private String mem_pwd; //�н�����
	private String mem_name; //�̸�
	private String mem_ph; //�ڵ��� ��ȣ
	private String mem_email; //�̸���-JS
	private String mem_gender; //'F''M'����/����
	private int mem_cash = 0; //ȸ�� cash
	private String mem_birth; //���� 00-00-00
	private String mem_jdate;// ȸ�� ȸ������ ��¥
	private String myle_num; // ȸ�� ���θ�� ������ ��� - Silver, Gold, Diamond
	private String mem_zip; // �ּҹ�ȣ
	private String mem_addr1; // �ּ�1
	private String mem_addr2; // �ּ�2
	

	private int gra_num;


	private int proj_num; //��ǰ �Ϸù�ȣ
	private String proj_name; //��ǰ �̸�
	private int proj_tm; //��ǰ �ݾ�
	private String proj_cont; //��ǰ ����
	private String proj_img_1; //��ǰ�̹���1
	private Date proj_jdate; //��ǰ �����
	private int proj_count;  //��ǰ ���� 

	
	private String join_num; //�ֹ���ȣ
	private Date join_jdate; //�ֹ�����
	private int join_amount; //�� �ݾ� 
	private int join_count; //��ǰ����

	private String join_delivery; //��ۻ���
	
	
	private int review_num;
	private String review_content;
	private int star;
	// ���� ����ۼ�
	private int review_star;

	// ���� list 
	private String review_jdate;
	
	
	private String tableName;
	//�̰ɷ� ����
	
	private String type = "";
	private String keyword = "";
	private int   page = 1;
	private int   startRow = 1;
	private int   endRow = 1;
	
	private int review_star_avg;
	
	
	public int getGra_num() {
		return gra_num;
	}
	public void setGra_num(int gra_num) {
		this.gra_num = gra_num;
	}
	
	
	public int getReview_num() {
		return review_num;
	}
	public void setReview_num(int review_num) {
		this.review_num = review_num;
	}
	public String getReview_content() {
		return review_content;
	}
	public void setReview_content(String review_content) {
		this.review_content = review_content;
	}
	public int getStar() {
		return star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	public int getReview_star() {
		return review_star;
	}
	public void setReview_star(int review_star) {
		this.review_star = review_star;
	}
	public String getReview_jdate() {
		return review_jdate;
	}
	public void setReview_jdate(String review_jdate) {
		this.review_jdate = review_jdate;
	}
	
	
	
	public String getJoin_delivery() {
		return join_delivery;
	}
	public void setJoin_delivery(String join_delivery) {
		this.join_delivery = join_delivery;
	}
	
	public int getReview_star_avg() {
		return review_star_avg;
	}
	public void setReview_star_avg(int review_star_avg) {
		this.review_star_avg = review_star_avg;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getStartRow() {
		return startRow;
	}
	public void setStartRow(int startRow) {
		this.startRow = startRow;
	}
	public int getEndRow() {
		return endRow;
	}
	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_pwd() {
		return mem_pwd;
	}
	public void setMem_pwd(String mem_pwd) {
		this.mem_pwd = mem_pwd;
	}
	public String getMem_name() {
		return mem_name;
	}
	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}
	public String getMem_ph() {
		return mem_ph;
	}
	public void setMem_ph(String mem_ph) {
		this.mem_ph = mem_ph;
	}
	public String getMem_email() {
		return mem_email;
	}
	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}
	public String getMem_gender() {
		return mem_gender;
	}
	public void setMem_gender(String mem_gender) {
		this.mem_gender = mem_gender;
	}
	public int getMem_cash() {
		return mem_cash;
	}
	public void setMem_cash(int mem_cash) {
		this.mem_cash = mem_cash;
	}
	public String getMem_birth() {
		return mem_birth;
	}
	public void setMem_birth(String mem_birth) {
		this.mem_birth = mem_birth;
	}
	public String getMem_jdate() {
		return mem_jdate;
	}
	public void setMem_jdate(String mem_jdate) {
		this.mem_jdate = mem_jdate;
	}
	public String getMyle_num() {
		return myle_num;
	}
	public void setMyle_num(String myle_num) {
		this.myle_num = myle_num;
	}
	public String getMem_zip() {
		return mem_zip;
	}
	public void setMem_zip(String mem_zip) {
		this.mem_zip = mem_zip;
	}
	public String getMem_addr1() {
		return mem_addr1;
	}
	public void setMem_addr1(String mem_addr1) {
		this.mem_addr1 = mem_addr1;
	}
	public String getMem_addr2() {
		return mem_addr2;
	}
	public void setMem_addr2(String mem_addr2) {
		this.mem_addr2 = mem_addr2;
	}
	public int getProj_num() {
		return proj_num;
	}
	public void setProj_num(int proj_num) {
		this.proj_num = proj_num;
	}
	public String getProj_name() {
		return proj_name;
	}
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	public int getProj_tm() {
		return proj_tm;
	}
	public void setProj_tm(int proj_tm) {
		this.proj_tm = proj_tm;
	}
	public String getProj_cont() {
		return proj_cont;
	}
	public void setProj_cont(String proj_cont) {
		this.proj_cont = proj_cont;
	}
	public String getProj_img_1() {
		return proj_img_1;
	}
	public void setProj_img_1(String proj_img_1) {
		this.proj_img_1 = proj_img_1;
	}
	public Date getProj_jdate() {
		return proj_jdate;
	}
	public void setProj_jdate(Date proj_jdate) {
		this.proj_jdate = proj_jdate;
	}
	public int getProj_count() {
		return proj_count;
	}
	public void setProj_count(int proj_count) {
		this.proj_count = proj_count;
	}
	public String getJoin_num() {
		return join_num;
	}
	public void setJoin_num(String join_num) {
		this.join_num = join_num;
	}
	public Date getJoin_jdate() {
		return join_jdate;
	}
	public void setJoin_jdate(Date join_jdate) {
		this.join_jdate = join_jdate;
	}
	public int getJoin_amount() {
		return join_amount;
	}
	public void setJoin_amount(int join_amount) {
		this.join_amount = join_amount;
	}
	public int getJoin_count() {
		return join_count;
	}
	public void setJoin_count(int join_count) {
		this.join_count = join_count;
	}
	
	
	
	

}
