package com.dla.daisseo.model;



public class Shopping_basket_daVo {
	// ��ٱ���

	private int bas_num; //��ٱ��� �Ϸù�ȣ
	private String bas_date; //��ٱ��� ���� ��¥
	
	private String mem_id; // ��ٱ����� ���̵�

	private int bas_count; //��ǰ ���� - ��ٱ��Ͽ� ���� ����
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// ��ٱ��� list
	private int proj_num; //��ǰ �Ϸù�ȣ
	private String proj_img_1; //��ǰ �̹���
	private String proj_name; // ��ǰ�̸�
	private int proj_tm; // ���� �� �� ���� �ݾ�
	private int proj_delok; // ��۷� ����
		
	
	public int getProj_delok() {
		return proj_delok;
	}
	public void setProj_delok(int proj_delok) {
		this.proj_delok = proj_delok;
	}
	public String getProj_img_1() {
		return proj_img_1;
	}
	public void setProj_img_1(String proj_img_1) {
		this.proj_img_1 = proj_img_1;
	}
	public String getProj_name() {
		return proj_name;
	}
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	public int getProj_tm() {
		return proj_tm;
	}
	public void setProj_tm(int proj_tm) {
		this.proj_tm = proj_tm;
	}
	public int getBas_count() {
		return bas_count;
	}
	public void setBas_count(int bas_count) {
		this.bas_count = bas_count;
	}

	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getProj_num() {
		return proj_num;
	}
	public void setProj_num(int proj_num) {
		this.proj_num = proj_num;
	}
	public int getBas_num() {
		return bas_num;
	}
	public void setBas_num(int bas_num) {
		this.bas_num = bas_num;
	}
	public String getBas_date() {
		return bas_date;
	}
	public void setBas_date(String bas_date) {
		this.bas_date = bas_date;
	}
	
	@Override
	public String toString() {
		return "Shopping_basket_daVo [bas_num=" + bas_num + ", mem_id=" + mem_id + ", proj_num="
				+ proj_num + ", bas_date=" + bas_date + "]";
	}
	
}
