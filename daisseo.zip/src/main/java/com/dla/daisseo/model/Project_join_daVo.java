package com.dla.daisseo.model;

import java.sql.Date;

public class Project_join_daVo {
	// ��ǰ ���� ���̺�
	
	private String join_num; //�ֹ���ȣ
	private String mem_id; //���̵�
	private int proj_num; //��ǰ��ȣ
	private Date join_jdate; //�ֹ�����
	private int join_amount; //�� �ݾ� 
	private int join_count; //��ǰ����
////////////////////////////////////////////
	private int mem_cash; //�����Ҷ� ������ ��Ÿ�������� ����Ʈ
	
	private String join_delivery;
	
	

	public String getJoin_delivery() {
		return join_delivery;
	}
	public void setJoin_delivery(String join_delivery) {
		this.join_delivery = join_delivery;
	}
	public int getMem_cash() {
		return mem_cash;
	}
	public void setMem_cash(int mem_cash) {
		this.mem_cash = mem_cash;
	}
	public int getJoin_amount() {
		return join_amount;
	}
	public void setJoin_amount(int join_amount) {
		this.join_amount = join_amount;
	}
	public String getJoin_num() {
		return join_num;
	}
	public void setJoin_num(String join_num) {
		this.join_num = join_num;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getProj_num() {
		return proj_num;
	}
	public void setProj_num(int proj_num) {
		this.proj_num = proj_num;
	}
	public Date getJoin_jdate() {
		return join_jdate;
	}
	public void setJoin_jdate(Date join_jdate) {
		this.join_jdate = join_jdate;
	}

	public int getJoin_count() {
		return join_count;
	}
	public void setJoin_count(int join_count) {
		this.join_count = join_count;
	}

	
	
	

	
	
}
