package com.dla.daisseo.model;



public class Project_daVo {
	// ��ǰ ���
	private int proj_num; //��ǰ �Ϸù�ȣ
	private String proj_name; //��ǰ �̸�
	private int proj_tm; //��ǰ �ݾ�
	private String proj_cont; //��ǰ ����
	private String proj_simplecont; //��ǰ ���ܳ���
	private String proj_img_1; //��ǰ�̹���1
	private String proj_img_2; //��ǰ�̹���2
	private String proj_img_3; //��ǰ�̹���3
	private String proj_jdate; //��ǰ �����
	private int proj_count;  //��ǰ ���� 
	private int proj_disc; //���η�
	private int proj_delok; // ��۷� ����
	private String mem_id; //���̵� ���۷���
	private int typ_num; // ī�װ��� Ÿ�� ���۷���
	
	///////////////////////////////	///////////////////////////////	///////////////////////////////	///////////////////////////////	///////////////////////////////	///////////////////////////////
	private int review_star_avg;
	// ��ǰ ����Ʈ�� ������ ���� ���� ���
	
	
	public int getReview_star_avg() {
		return review_star_avg;
	}
	public void setReview_star_avg(int review_star_avg) {
		this.review_star_avg = review_star_avg;
	}
	public int getProj_count() {
		return proj_count;
	}
	public void setProj_count(int proj_count) {
		this.proj_count = proj_count;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getTyp_num() {
		return typ_num;
	}
	public void setTyp_num(int typ_num) {
		this.typ_num = typ_num;
	}
	public int getProj_num() {
		return proj_num;
	}
	public void setProj_num(int proj_num) {
		this.proj_num = proj_num;
	}
	public String getProj_name() {
		return proj_name;
	}
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	public int getProj_tm() {
		return proj_tm;
	}
	public void setProj_tm(int proj_tm) {
		this.proj_tm = proj_tm;
	}
	public String getProj_cont() {
		return proj_cont;
	}
	public void setProj_cont(String proj_cont) {
		this.proj_cont = proj_cont;
	}
	public String getProj_simplecont() {
		return proj_simplecont;
	}
	public void setProj_simplecont(String proj_simplecont) {
		this.proj_simplecont = proj_simplecont;
	}
	public String getProj_img_1() {
		return proj_img_1;
	}
	public void setProj_img_1(String proj_img_1) {
		this.proj_img_1 = proj_img_1;
	}
	public String getProj_img_2() {
		return proj_img_2;
	}
	public void setProj_img_2(String proj_img_2) {
		this.proj_img_2 = proj_img_2;
	}
	public String getProj_img_3() {
		return proj_img_3;
	}
	public void setProj_img_3(String proj_img_3) {
		this.proj_img_3 = proj_img_3;
	}
	public String getProj_jdate() {
		return proj_jdate;
	}
	public void setProj_jdate(String proj_jdate) {
		this.proj_jdate = proj_jdate;
	}
	public int getProj_disc() {
		return proj_disc;
	}
	public void setProj_disc(int proj_disc) {
		this.proj_disc = proj_disc;
	}
	public int getProj_delok() {
		return proj_delok;
	}
	public void setProj_delok(int proj_delok) {
		this.proj_delok = proj_delok;
	}
	
	@Override
	public String toString() {
		return "Project_daVo [proj_num=" + proj_num + ", proj_name=" + proj_name + ", proj_tm=" + proj_tm + ", proj_cont=" + proj_cont + ", proj_simplecont=" + proj_simplecont + ", proj_img_1=" + proj_img_1 + ", proj_img_2=" + proj_img_2 + ", proj_img_3=" + proj_img_3
				+ ", proj_jdate=" + proj_jdate + ", proj_count=" + proj_count + ", proj_disc=" + proj_disc + ", proj_delok=" + proj_delok + ", mem_id=" + mem_id + ", typ_num=" + typ_num + "]";
	}

}
