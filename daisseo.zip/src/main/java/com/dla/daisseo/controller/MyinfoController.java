package com.dla.daisseo.controller;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dla.daisseo.model.Career_daVo;
import com.dla.daisseo.model.ListVo;
import com.dla.daisseo.model.Member_daVo;
import com.dla.daisseo.model.Project_daVo;
import com.dla.daisseo.model.Project_join_daVo;
import com.dla.daisseo.model.Review_daVo;
import com.dla.daisseo.model.SearchVO;
import com.dla.daisseo.model.Shopping_basket_daVo;
import com.dla.daisseo.model.Shopping_orderVo;
import com.dla.daisseo.service.MemberService;
import com.dla.daisseo.service.MyinfoService;
import com.dla.daisseo.service.ProductService;
import com.dla.daisseo.utills.BCrypt;

@Controller
@RequestMapping("myinfo")
public class MyinfoController {
	
	@Autowired
	private MyinfoService myinfoservice;
	
	@Autowired
	private MemberService memberservice;
	
	@Autowired
	private ProductService productservice;
	

	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String myinfomain(HttpSession session, Model model) throws Exception{
		String mem_id  = (String) session.getAttribute("mem_id");
		String mem_ok = myinfoservice.mem_ok(mem_id);
		model.addAttribute("mem_ok", mem_ok);
		
		return "MyInfo/MyInfo";
	}
	
	
	// ��ٱ��� ��� - proj_tm ���������� 
	@RequestMapping(value = "/cartlist", method = RequestMethod.GET)
	public String getCartList(HttpSession session, Model model)throws Exception{

		String mem_id  = (String) session.getAttribute("mem_id");

		List<Shopping_basket_daVo> cartList = myinfoservice.cartList(mem_id);

		model.addAttribute("cartList", cartList);
		return "MyInfo/ShoppingBasket";

	}
	
	// ��ٱ��� ��� ����
	@ResponseBody
	@RequestMapping(value = "/deletecart", method = RequestMethod.POST)
	public int deleteCart(HttpSession session,
	     @RequestParam(value = "chBox[]") List<String> chArr, Shopping_basket_daVo cart) throws Exception{
	 
		String mem_id  = (String) session.getAttribute("mem_id");
	 
	 int bas_num = 0;
	 int result = 0;
	 
	 
	 if(mem_id != null) {
	  cart.setMem_id(mem_id);
	  
	  for(String i : chArr) {
	   bas_num = Integer.parseInt(i);
	   //interget.parseInt �� ���ص� ��Ʈ�� �̱���
	   cart.setBas_num(bas_num);
	   myinfoservice.deleteCart(cart);
	  }   
	  result = 1;
	  
	 }  
	 return result;
	}
	
	// ��ٱ��Ͽ��� �ֹ��ϱ�
	@RequestMapping(value = "/cartlistorder", method = RequestMethod.POST)
		 public String order(Model model, HttpSession session, Project_join_daVo order, 
			Shopping_basket_daVo bas,@RequestParam(value = "chk[]") List<String> chArr, 
				 					 @RequestParam(value = "amount") String amount) throws Exception {
		
			String mem_id  = (String) session.getAttribute("mem_id");
			int bas_num = 0;
			int a = 0;
		  for(String i : chArr){
		      //�ֹ���ȣ(orderId) ������ ���� ����
			  Calendar cal = Calendar.getInstance();
			  int year = cal.get(Calendar.YEAR);
			  String ym = year + new DecimalFormat("00").format(cal.get(Calendar.MONTH) + 1);
			  String ymd = ym + new DecimalFormat("00").format(cal.get(Calendar.DATE));
			  String subNum = "";
			  
			  for(int i1 = 1; i1 <= 6; i1 ++) {
			   subNum += (int)(Math.random() * 10);
			  }
			  
			  String join_num = ymd + "_" + subNum; //ex) 20200508_373063
			  
			  bas_num = Integer.parseInt(i);
			  
			  Shopping_orderVo shoder = myinfoservice.ShoppingOrder(bas_num);
			  
			  order.setJoin_amount(shoder.getJoin_amount());
			  order.setJoin_count(shoder.getBas_count());
			  order.setJoin_num(join_num);
			  order.setMem_id(mem_id);
			  order.setProj_num(shoder.getProj_num());
			  
			  myinfoservice.cartlistorder(order);

			  a += shoder.getJoin_amount();
			  // �ݾ�ó���� ���� �ڵ�

   
		  }
		  Member_daVo member = memberservice.pointSelect(mem_id);
		  
		  
		  int b = member.getMem_cash();

		  if(a>b) {
			  model.addAttribute("errCode", "1");
				return "MyInfo/ShoppingBasket";
			  // �ݾ��� �����ϸ� ���Ű� �ȵ�
		  }else {
			  int cashval = b-a;
			  //System.out.print("�ݾ�ó��");
	  
			  member.setMem_cash(cashval);
			  memberservice.pointupdate(member);
			  
			  for(String i : chArr){
		      bas_num = Integer.parseInt(i);
			  bas.setMem_id(mem_id);
			  bas.setBas_num(bas_num);
			  myinfoservice.deleteCart(bas);
			  }
			  session.setAttribute("mem_cash", cashval);
			  
		  }
		  
		  return "redirect:/myinfo/orderlist";  
		 }

	// �Ǹų��� ����Ʈ
	 @RequestMapping(value="/uploadlist", method=RequestMethod.GET)
		public String mainList(Model model, HttpSession session, ListVo listvO) throws Exception{
		 
		 	String mem_id = (String)session.getAttribute("mem_id");	
		 
		 	listvO.setTableName("UploadList");
		 	listvO.setMem_id(mem_id);
		  	
		 	int totalrow = myinfoservice.getTotalRow(listvO);
		 	
		 	model.addAttribute("totalrow", totalrow);

		 	List<ListVo> uploadlist = myinfoservice.list(listvO);
			//for(ListVo listvo: uploadlist) {
//				listvo.setTableName("UploadList");
				
			//}

			StringBuffer pageUrl = myinfoservice.getPageUrl(listvO);
			model.addAttribute("pageHttp", pageUrl);
		

			model.addAttribute("uploadlist", uploadlist);	

		  		 
		 return "MyInfo/ProductUploadList"; 
	 }
	 
	 // �ش� ��ǰ�� �ֹ�������  ���
	 @RequestMapping(value="/orderManage", method=RequestMethod.GET)
		public String ordermanage(@RequestParam(value = "proj_num") int proj_num, Model model, HttpSession session, ListVo listvO,
				HttpServletRequest request) throws Exception{
		 
		 	model.addAttribute("proj_num", proj_num);
		 
		 	String mem_id = (String)session.getAttribute("mem_id");
		 	
		 	listvO.setTableName("orderManagement");
		 	listvO.setProj_num(proj_num);
		  	
		 	int totalrow = myinfoservice.getTotalRow(listvO);
		 	
		 	model.addAttribute("totalrow", totalrow);
		 	
		  	
		 	List<ListVo> orderinfolist = myinfoservice.list(listvO);
		 	
			StringBuffer pageUrl = myinfoservice.getPageUrl(listvO);
			model.addAttribute("pageHttp", pageUrl);
			
			model.addAttribute("orderinfolist", orderinfolist);	
		 
		 return "MyInfo/Sell-ProductMG";
	 }
	 
	 
	// �ֹ� �� ��� - ���� ����
	 @RequestMapping(value = "/orderManage", method = RequestMethod.POST)
	 public String delivery(HttpSession session, HttpServletRequest httpServletRequest, Model model, Project_daVo product, Project_join_daVo productjoin)  throws Exception {
		 

		String join_num = httpServletRequest.getParameter("join_num");
		int proj_num = Integer.parseInt(httpServletRequest.getParameter("proj_num"));
		int proj_count = Integer.parseInt(httpServletRequest.getParameter("proj_count"));
		String delivery = httpServletRequest.getParameter("delivery");
		String asd = httpServletRequest.getParameter("asd");

		
		if(delivery.equals("��� ��")){
			productjoin.setJoin_delivery(delivery);
			productjoin.setJoin_num(join_num);
			myinfoservice.deliveryUpdate(productjoin);
		}else {
			productjoin.setJoin_delivery(delivery);
			productjoin.setJoin_num(join_num);
			
			myinfoservice.deliveryUpdate(productjoin);
			product.setProj_count(proj_count);
			product.setProj_num(proj_num);
			myinfoservice.productCountUpdate(product);
		}
		return "redirect:/myinfo/orderManage?proj_num=" +proj_num;
	  //return "MyInfo/Sell-ProductMG";
	 }
	 
	 
		// �ֹ����� ����Ʈ
	 @RequestMapping(value="/orderlist", method=RequestMethod.GET)
		public String orderList(Model model, HttpSession session, ListVo listvO, Review_daVo reviewvo) throws Exception{
		 
		 	String mem_id = (String)session.getAttribute("mem_id");	
		 
		 	listvO.setTableName("orderlist");
		 	listvO.setMem_id(mem_id);
		  	
		 	int totalrow = myinfoservice.getTotalRow(listvO);
		 	
		 	model.addAttribute("totalrow", totalrow);
		 	
		 	List<ListVo> orderlist = myinfoservice.list(listvO);		 
		 	
			StringBuffer pageUrl = myinfoservice.getPageUrl(listvO);
			model.addAttribute("pageHttp", pageUrl);
		
			model.addAttribute("orderlist", orderlist);	
			/*
		 	for(ListVo a : orderlist) {
		 		reviewvo.setProj_num(a.getProj_num());
		 		reviewvo.setMem_id(mem_id);
		 		
		 		if(productservice.reviewConfirm(reviewvo) != 0) {
		 			model.addAttribute("reviewCode", 1);

		 		}//else {
	 			model.addAttribute("reviewCode", 0);


		 		}
		 	}
		 	*/
		 return "MyInfo/orderList"; 

	 }
	 
		// ������ ���� ��ü ��ǰ ��ȸ
	 @RequestMapping(value="/productlist", method=RequestMethod.GET)
		public String productlist(Model model, HttpSession session, ListVo listvO)throws Exception {
		 
		 	String mem_id = (String)session.getAttribute("mem_id");	
		 
		 	listvO.setTableName("productlist");
		 	listvO.setMem_id(mem_id);
		  	
		 	int totalrow = myinfoservice.getTotalRow(listvO);
		 	
		 	model.addAttribute("totalrow", totalrow);
		 	
		 	List<ListVo> productlist = myinfoservice.list(listvO);		 


			StringBuffer pageUrl = myinfoservice.getPageUrl(listvO);
			model.addAttribute("pageHttp", pageUrl);
		

			model.addAttribute("productlist", productlist);	

		  		 
		 return "MyInfo/Admin-ProductMG"; 
		 
	 }
	 
	 
	 //�Ǹ�ȸ�� ��û
	 @RequestMapping(value = "/permission", method=RequestMethod.GET)
		public String permission() throws Exception{
		return "Member/PermissionForm";
		 
	 }
	 
	 //�Ǹ�ȸ��ȸ�� ��û
	 @RequestMapping(value = "/permission", method=RequestMethod.POST)
	 public String permissionpro(Career_daVo career, Model model, HttpSession session, HttpServletRequest request)throws Exception {
		 
		 	String mem_id = (String)session.getAttribute("mem_id");
			
			String[] car_sdate = request.getParameterValues("car_sdate");
			String[] car_fdate = request.getParameterValues("car_fdate");
			String[] car_org = request.getParameterValues("car_org");
			String[] car_act = request.getParameterValues("car_act");
			
			for(int i=0; i<car_sdate.length; i++){
				career.setCar_sdate(car_sdate[i]);
				career.setCar_fdate(car_fdate[i]);
				career.setCar_org(car_org[i]);
				career.setCar_act(car_act[i]);
				career.setMem_id(mem_id);
				 myinfoservice.permission(career);
			}			
			
		 myinfoservice.permissionupdate(mem_id);
		 model.addAttribute("ServerCode","1");
		return "Member/PermissionForm";		 
	 }
	 


	 // �Ǹ�ȸ�� ?List
	 @RequestMapping(value = "permissionlistmember", method = RequestMethod.GET)
	 public String permissionmember(Model model, ListVo listvo) throws Exception{
		 
		 listvo.setTableName("permissionlistmember");

		 int totalrow = myinfoservice.getTotalRow(listvo);
		 model.addAttribute("totalrow", totalrow);
		 
		 List<ListVo> permissionlist = myinfoservice.list(listvo);

		 StringBuffer pageUrl = myinfoservice.getPageUrl(listvo);
		 model.addAttribute("pageHttp",pageUrl);
		 model.addAttribute("permissionlist", permissionlist);
		 
		 return "MyInfo/PermissionList";
	 }

	// �ǸŽ�û�� ����� �� 
	 @RequestMapping(value = "permissionupdateform", method = RequestMethod.GET)
	 public  String permissionuypdateform(@RequestParam("mem_id")String mem_id, Model model) throws Exception{
		 
		 List<Career_daVo> updateformlist = myinfoservice.permissionupdateform(mem_id);
		 model.addAttribute("updateformlist",updateformlist);
		 model.addAttribute("mem_id", mem_id);
		 if(updateformlist == null) {
			 model.addAttribute("ServerCode",1);
			 return "MyInfo/PermissionList";

		 }
		 return "MyInfo/permissionupdateform";
		 
}
	 //�ǸŽ���
	 @RequestMapping(value = "/permissionok", method=RequestMethod.GET)
	 public String ok(Model model, @RequestParam("mem_id")String mem_id) throws Exception{
		 
		 myinfoservice.permissionok(mem_id);
		 model.addAttribute("ServerCode",2);
			return "MyInfo/PermissionList";		 
	 }
	 
	 //�ǸŰ���
	 @RequestMapping(value = "/permissionfail", method=RequestMethod.GET)
	 public String fail(@RequestParam("mem_id")String mem_id, Model model) throws Exception{
		 
		 myinfoservice.permissionfail(mem_id);
		 model.addAttribute("ServerCode",3);
			return "Member/PermissionList";		 
	 }
	 
	 //ȸ�� ����Ʈ
	 @RequestMapping(value = "memberlist", method = RequestMethod.GET)
	 public String memberlist(Model model, ListVo listvo)throws Exception{
		 
		 listvo.setTableName("memberlist");

		 int totalrow = myinfoservice.getTotalRow(listvo);
		 model.addAttribute("totalrow", totalrow);
		 
		 List<ListVo> memberlist = myinfoservice.list(listvo);

		 StringBuffer pageUrl = myinfoservice.getPageUrl(listvo);
		 model.addAttribute("pageHttp",pageUrl);
		 model.addAttribute("memberlist", memberlist);
		 
		 return "MyInfo/Admin-MemberMG";
	 }
	 
	 

	 //(����)ȸ�� ã�� �� ���� 
	 @RequestMapping(value = "/myDel", method = RequestMethod.GET)
	 public String myDelform(HttpSession session, Model model) throws Exception {
		 String mem_id = (String)session.getAttribute("mem_id");
		 model.addAttribute("mem_id", mem_id);
		 return "MyInfo/PassMod";
			
			
	 }

	 //(����)ȸ�� ã�� �� ����
	 @ResponseBody
	 @RequestMapping(value = "/myDel", method = RequestMethod.POST)
	 public String myDelpro(@RequestParam("mem_pwd") String mem_pwd, Member_daVo member, HttpSession session, BindingResult resultr, Model model) throws Exception{
		 
		 System.out.println("��Ʈ��"+mem_pwd);
		 String result = "2";
		 
		 
		 String mem_id = (String)session.getAttribute("mem_id");
		 
		 String mem_pwdDB = myinfoservice.passokConfirm(mem_id);
		 
		 
		 if(BCrypt.checkpw(mem_pwd, mem_pwdDB)) {
			 result = "1";
			 this.myinfoservice.memberDel(mem_id);
			 return result;	 
		 }else {
			 return result;	 
		 }
	
	 }
	 
	 //(������)ȸ������	 
		@RequestMapping(value = "/memberDel", method = RequestMethod.GET)
		public String memberlist(@RequestParam("mem_id") String mem_id) throws Exception {
			System.out.println("��Ʈ�ѷ�"+mem_id);
			this.myinfoservice.memberDel(mem_id); 
				return "redirect:/myinfo/memberlist";	
		}
		
		
		//ȸ�� ������ �׳� ���������� 
		@RequestMapping(value = "/myinfoform", method = RequestMethod.GET)
			public String myinfoform(HttpSession session, Model model) throws Exception {
			
			 String mem_id = (String)session.getAttribute("mem_id");
			 Member_daVo myinfoform = myinfoservice.myinfoform(mem_id);
			 System.out.println(myinfoform.getMem_name());
			 model.addAttribute("myinfoform", myinfoform);
			return "MyInfo/MemberMod";
			
		}
		
		//ȸ�� value ������ ���������� 
		@RequestMapping(value = "/myinfoupdate", method = RequestMethod.GET)
		public String myinfoupdateform(HttpSession session, Model model) throws Exception {
		
		 String mem_id = (String)session.getAttribute("mem_id");
		 Member_daVo myinfoform = myinfoservice.myinfoform(mem_id);
		 
		 
		 model.addAttribute("myinfoform", myinfoform);
		model.addAttribute("member_davo", new Member_daVo());
		 
		return "MyInfo/MemberModpro";
	}
		
		
		//ȸ�� value �� �����ϱ� 
		@RequestMapping(value = "/myinfoupdate", method = RequestMethod.POST)
		public String myinfoupdatepro(@ModelAttribute("member_davo") Member_daVo memberdavo, HttpSession session, Model model) throws Exception {
		
		 String mem_id = (String)session.getAttribute("mem_id");
		 
		 memberdavo.setMem_id(mem_id);
		 
		 if(myinfoservice.myinfoupdate(memberdavo) != 0) {
			 model.addAttribute("ServerCode",1);
		 }else {
			 model.addAttribute("ServerCode",2);			 
		 }
		  
		return "MyInfo/MemberModpro";
	}
		

	 }

 



