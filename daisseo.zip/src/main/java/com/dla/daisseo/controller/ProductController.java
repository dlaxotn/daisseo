package com.dla.daisseo.controller;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.dla.daisseo.model.ListVo;
import com.dla.daisseo.model.Member_daVo;
import com.dla.daisseo.model.Project_daVo;
import com.dla.daisseo.model.Project_join_daVo;
import com.dla.daisseo.model.Review_daVo;
import com.dla.daisseo.model.SearchVO;
import com.dla.daisseo.model.Shopping_basket_daVo;
import com.dla.daisseo.model.type_daVo;
import com.dla.daisseo.service.MemberService;
import com.dla.daisseo.service.MyinfoService;
import com.dla.daisseo.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productservice;
	
	@Autowired
	private MemberService memberservice;
	
	@Autowired
	private MyinfoService myinfoservice;
	
	
	
	String uploadPath = "E:\\1215\\1215\\daiss_eo(1215)\\src\\main\\webapp\\resources\\productimg\\";
	// 상품 등록시 상품 등록 경로
	// 코드 보실때 이 경로를 해당 프로젝트 productimg 폴더 경로로 해주셔야 합니다.
	// 이클립스+톰캣 을 사용하는 경우라 로컬에서 실행되는 경로(배포경로)와 업로드 경로(workspace)가 다르기 때문에 이미지를 바로 찾지 못해서 업로드 후 메이븐 update 한 후 실행해야 엑박 없이 이미지가 나타나는데  
	// 이클립스에서 Window → Preferences → General → Workspace 의 Refresh using native hooks or polling 체크를 해주면 업로드 후 바로 엑박이 아닌 이미지가 바로 로드 됩니다.
	// 위와 같은 설정을 해주면 이클립스가 새로고침 하면서 workspace 에 저장된 이미지를 배포 경로쪽으로복사해 주기 때문에 이미지가 깨지지않고 보이는 것


	
	
	
	
	
	//String uploadPath = "C:\\eclipse\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\daiss_eo\\resources\\productimg\\";

	
	
@RequestMapping(value="/productupload", method=RequestMethod.GET)
	public String productUpload(Model model, HttpSession session) throws Exception {
		model.addAttribute("projectdavo", new Project_daVo());
	return "/Product/ProductUpload";
	}
		//from:input 을 사용하려면 model 
	

	@RequestMapping(value="/productupload", method=RequestMethod.POST)
	public String Uploadpro(@ModelAttribute("projectdavo") Project_daVo projectdavo, HttpSession session,
	        MultipartHttpServletRequest request, Model model) throws Exception{

	//새 글저장
	String content =  projectdavo.getProj_simplecont().replaceAll("\r\n", "<br />");
	content = content.replaceAll("<","&lt;");
	content = content.replaceAll(">","&gt;");
	content = content.replaceAll("&","&amp;");
	content = content.replaceAll("\"","&quot;");
	// 주요 내용 정리작업(java새줄 코드 HTML줄바꾸기로)

	projectdavo.setProj_simplecont(content);

	MultipartFile mf1 = request.getFile("file1");
	MultipartFile mf2 = request.getFile("file2");
	MultipartFile mf3 = request.getFile("file3");
	// 폼에서 파일을 name 값으로 파일을 받는다.

	
	String originFileName1 = mf1.getOriginalFilename(); // 원본
	String originFileName2 = mf2.getOriginalFilename(); // 원본
	String originFileName3 = mf3.getOriginalFilename(); // 원본
	// 받은 파일을 파일형으로 변환해준걸 오리지널파일네임으로 변환한다.
	

	
	String safeFile1 = uploadPath + originFileName1;
	String safeFile2 = uploadPath + originFileName2;
	String safeFile3 = uploadPath + originFileName3;
	//경로+파일명을 세이브파일에 집어넣은다.
	
	
	projectdavo.setProj_img_1(originFileName1);
	projectdavo.setProj_img_2(originFileName2);
	projectdavo.setProj_img_3(originFileName3);
	//DB에도 저장한다.
	
	try {
		
		mf1.transferTo(new File(safeFile1));
		mf2.transferTo(new File(safeFile2));
		mf3.transferTo(new File(safeFile3));
		//  경로+파일명 위치에 저장한다. 
		
	} catch (IllegalStateException e) {
		
		e.printStackTrace();
	} catch (IOException e) {

		e.printStackTrace();
	}
	

	 if(this.productservice.insertProduct(projectdavo) != 0) {//안되면 null 아니면으로 바꿈 
			//model.addAttribute("projectdavo", projectdavo);
		 	model.addAttribute("ServerCode","1");
			return "Product/ProductUpload";
			
		}else {
		 	model.addAttribute("ServerCode","2");
			return "Product/ProductUpload";
		}
	 
	}
	
	 //상품 메인 상품 출력 - 그다음 로직개발을위해 일단 다불러와서 작업중
	 @RequestMapping(value="/main", method=RequestMethod.GET)
		public String mainList(Model model, HttpSession session) throws Exception {
		 
		 
		  List<Project_daVo> productlist = productservice.list();
		  //인기리스트
			 model.addAttribute("prolist", productlist);	
			 
			 
		  List<Project_daVo> newlist = productservice.newprolist();
		  //최신상품 리스트
			 model.addAttribute("newlist", newlist);	
			 
			 
			 
		  List<Project_daVo> reviewlist = productservice.reviewprolist();
		  //리뷰순 리스트
			 model.addAttribute("reviewlist", reviewlist);		  		 
		 return "Main"; 
	 }
	 
	 // 서브메인 - 카테고리별 상품 리스트 출력 
	 @RequestMapping(value  = "/submain", method=RequestMethod.GET)
	 public String subgetmainlist(Model model, HttpSession session, @RequestParam(value = "typ_num") int typ_num)  throws Exception{
		 
		 
		 String value = null;
		 
		 if(productservice.typelist(typ_num) == null) {
			 model.addAttribute("title", "전체보기");		  		 
		 }else {
			 type_daVo typ = productservice.typelist(typ_num);
			 model.addAttribute("title",typ.getTyp_name());
		 }

		 List<Project_daVo> prolist = productservice.sublist(value, typ_num);
		 model.addAttribute("prolist", prolist);

		 
		 return "SubMain";
	 
	 }
	 

	 	// 그냥 상품 제목으로 고정시킬꺼기 때문에 파라미터 where 전에 오는 파라미터타입은 안가지고올것임
	 @RequestMapping(value  = "/search", method=RequestMethod.GET)
	 public String subpromainlist(@RequestParam(value = "search") String search,Model model, HttpSession session)  throws Exception{
		 		 
		 List<Project_daVo> prolist = productservice.sublist(search, 0);
		 model.addAttribute("prolist", prolist);

		 
		 return "SubMain";
	 }
	 
	 //상품 상세 내용
	 @RequestMapping(value = "/productcontent", method = RequestMethod.GET)
	 	public String productContent(@RequestParam("proj_num") int proj_num, Model model, Project_daVo project_davo, ListVo listvo, Review_daVo reviewvo, HttpSession session)  throws Exception{
		 
			String mem_id  = (String) session.getAttribute("mem_id");
			
			
			model.addAttribute("mem_id", mem_id);
			
			if(mem_id != null) {
				
				project_davo.setMem_id(mem_id);
				project_davo.setProj_num(proj_num);
				
				reviewvo.setMem_id(mem_id);
				reviewvo.setProj_num(proj_num);

				
			if(productservice.productupid(project_davo) != 0 || mem_id.equals("admin")) {
				  model.addAttribute("ServerCode", 1);
				  //상품 삭제를 위한 코드
				}
			
			int review_num = productservice.orderSelect(mem_id, proj_num);
			// 해당 상품 구입한 사람만 리뷰쓰게 하기 및 로그인이 안되어있으면 
			if(review_num == 0) {

				model.addAttribute("reviewCode", 0);
				//리뷰못씀 구매해야함
			}else{
				if(productservice.reviewConfirm(reviewvo) != 0) {
					model.addAttribute("reviewCode", 1);
				}else {
					model.addAttribute("reviewCode", 2);
				}
			}
		}
			
			 Project_daVo productcontent = productservice.productcontent(proj_num);

			 listvo.setProj_num(proj_num);
			 listvo.setTableName("reviewlist");
			 
			 model.addAttribute("content", productcontent);
			 
			 	int totalrow = myinfoservice.getTotalRow(listvo);
			 	model.addAttribute("totalrow", totalrow);
			 	
			 
			 	List<ListVo> reviewList = myinfoservice.list(listvo);

				model.addAttribute("reviewList", reviewList);
				
			 	StringBuffer pageUrl = myinfoservice.getPageUrl(listvo);
				model.addAttribute("pageHttp", pageUrl);
				
		 return "Product/ProductContent";
			
	 }
	 
		// 상품삭제
	 @ResponseBody
	 @RequestMapping(value = "/productDel", method = RequestMethod.POST)
	 public int productdel(@RequestParam("proj_num") int proj_num, HttpSession session) throws Exception {
		 
			String mem_id  = (String)session.getAttribute("mem_id");
		 
		  int result = 0;

		  if(productservice.productDel(proj_num) != 0) {
			  if(mem_id.equals("admin")) {
				  result = 0;
			  }else {
				  result = 1;  
			  }
		  }
				
		  return result;				

	 }
	 
	// 상품 조회 - 소감(댓글) 작성
	 @RequestMapping(value = "/productcontent", method = RequestMethod.POST)
	 public String registReply(Review_daVo review_davo, HttpSession session) throws Exception {

			String mem_id  = (String) session.getAttribute("mem_id");
			review_davo.setMem_id(mem_id);
			
			productservice.writerReview(review_davo);
			 
	  return "redirect:/product/productcontent?proj_num=" + review_davo.getProj_num();
	 }
	 
	 	//장바구니 담기
		@ResponseBody
		@RequestMapping(value = "/cart", method = RequestMethod.POST)
		public int addCart(Shopping_basket_daVo cart, HttpSession session)  throws Exception{
			
			int result = 0;
			
			String mem_id  = (String) session.getAttribute("mem_id");
			
			cart.setMem_id(mem_id);

			if(mem_id != null) {
			productservice.addCart(cart);
				result = 1;
			}

			return result;
					
		}
		//구매하기
		@ResponseBody
		@RequestMapping(value = "/contentorder", method = RequestMethod.POST)
		public String addorder(Project_join_daVo order, HttpSession session, @RequestParam(value = "join_amount") int join_amount, Model model)  throws Exception{
			
			String result = null;
			
			String mem_id  = (String) session.getAttribute("mem_id");
			
			  //주문번호(orderId) 생성을 위한 로직
			  Calendar cal = Calendar.getInstance();
			  int year = cal.get(Calendar.YEAR);
			  String ym = year + new DecimalFormat("00").format(cal.get(Calendar.MONTH) + 1);
			  String ymd = ym + new DecimalFormat("00").format(cal.get(Calendar.DATE));
			  String subNum = "";
			  
			  for(int i1 = 1; i1 <= 6; i1 ++) {
			   subNum += (int)(Math.random() * 10);
			  }
			  
			  String join_num = ymd + "_" + subNum; //ex) 20200508_373063
			
			order.setMem_id(mem_id);
			order.setJoin_num(join_num);

			if(mem_id != null) {
				int amount = join_amount;
				Member_daVo member = memberservice.pointSelect(mem_id);
				int a = member.getMem_cash();

				if(amount>a) {
					result = "2";
					return result;
					// 금액이 부족하면 구매가 안되지롱
				}else {
					int cashval = a-amount;
					member.setMem_cash(cashval);
				    memberservice.pointupdate(member);
					productservice.contentOrder(order);
					
					session.setAttribute("mem_cash", cashval);
					// 캐쉬 세팅이요
				}
				result = "1";
			}else {
				result = "0";
			}

			return result;
					
		}
		
		@RequestMapping(value = "/reviewDel", method = RequestMethod.GET)
			public String reviewDel(HttpSession session, Model model, @RequestParam(value = "review_num") int review_num) throws Exception{
			
			
			try { 
				productservice.reviewDel(review_num);
				
			} catch (Exception e) {
				System.out.println("예외 발생");
			}
			
			return "redirect:/product/productcontent";
		}
			
		
		
		
		
		
}

	



	
	
	
