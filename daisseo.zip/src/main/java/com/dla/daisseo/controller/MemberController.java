package com.dla.daisseo.controller;

import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dla.daisseo.model.Member_daVo;
import com.dla.daisseo.service.MemberService;
import com.dla.daisseo.utills.BCrypt;

	@Controller
	@RequestMapping("/member")
	public class MemberController {
		 
		
		@Autowired
		private MemberService memberservice;

		
		@RequestMapping(value = "/pointcharge", method = RequestMethod.GET)
		public String pointCharge() throws Exception{
			return "/point/CashRecharge";
		}
		
		@RequestMapping(value = "/pointcharge", method = RequestMethod.POST)
		public String PCsubmit(HttpServletRequest httpServletRequest, HttpSession session, Member_daVo member_davo, Model model) throws Exception{
			
			String mem_id  = (String) session.getAttribute("mem_id");
			
			member_davo = memberservice.pointSelect(mem_id);
			int cashorg = member_davo.getMem_cash();  
			int cash = Integer.parseInt(httpServletRequest.getParameter("cp_item"));
			int cashupdate = cashorg+cash;
			member_davo.setMem_id(mem_id);
			member_davo.setMem_cash(cashupdate);

			if(memberservice.pointupdate(member_davo) != 0) {
				model.addAttribute("ServerCode", 1);
				session.setAttribute("mem_cash", cashupdate);
				return "/point/CashRecharge";
			}else {
				model.addAttribute("ServerCode", 2);
				return "/point/CashRecharge";

			}

			
		}
		
		@RequestMapping(value = "/join", method = RequestMethod.GET)
		public String toUserEntryView(Model model) throws Exception{
			model.addAttribute("member_davo", new Member_daVo());
			return "/Member/MemberJoin";
			 //join ��ũ�� �ٶ������ model�� member_davo�� �ִ´�.
		}
		
		// POST ó���� ���� ���� �Է��Ҷ� ����ϴ� �����̴�.
		@RequestMapping(value = "/join", method = RequestMethod.POST)
		public String onSubmit(@ModelAttribute("member_davo")@Valid Member_daVo member_davo, BindingResult result, Model model)throws Exception {


			if(member_davo.getEmail_2() == null) {
				member_davo.setMem_email(member_davo.getEmail_1()+"@"+member_davo.getEmail_3());
			}else {
				member_davo.setMem_email(member_davo.getEmail_1()+"@"+member_davo.getEmail_2());
				}
			//�̸��� ����/����
			
			member_davo.setMem_birth(member_davo.getYear()+"/"+member_davo.getMonth()+"/"+member_davo.getDay());
			//���� �ֱ�
			
			if(result.hasErrors()) {
				model.addAllAttributes(result.getModel());
				return "/Member/MemberJoin";
			}
			
			// passwd ��ȣȭ
			String hashPass = BCrypt.hashpw(member_davo.getMem_pwd(), BCrypt.gensalt(12));
			member_davo.setMem_pwd(hashPass); // ��ȣȭ�� passwd �� ����
		
			if(this.memberservice.insertMember(member_davo) != 0) {//�ȵǸ� null �ƴϸ����� �ٲ� 
				model.addAttribute("complete", 1);
				model.addAttribute("member_davo", member_davo);
				return "/Member/MemberJoin";
			}
			else {
				return "/Member/MemberJoin";
			}
		}
		
		@RequestMapping(value  = "/checkid", method = RequestMethod.GET)
		public String duplicateId(@RequestParam("mem_id") String mem_id, Model model) throws Exception {
			
			String message = "";
			int available = 0;
			
			try {
				Member_daVo loginUser = this.memberservice.getMember(mem_id);
				if(loginUser == null ) {
					message = "��� ������ ���̵� �Դϴ�.";
					available = 1;
				}else{
				message = "�̹� ���� ���̵� �Դϴ�.";
				available = 0;
				mem_id = "";
				}
				
			}catch (EmptyResultDataAccessException e) {
				message = "�����߻�";

			}
			model.addAttribute("member_davo", new Member_daVo());
			model.addAttribute("message", message); 
			model.addAttribute("available", available);
			model.addAttribute("mem_id", mem_id);
			// availble/ message �� �ߺ�Ȯ�������� ��
			return "/Member/MemberJoin";
			
		}

}
