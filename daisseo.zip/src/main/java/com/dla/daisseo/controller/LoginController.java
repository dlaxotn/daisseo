package com.dla.daisseo.controller;

import java.lang.management.MemoryUsage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dla.daisseo.model.Grade_daVo;
import com.dla.daisseo.model.Member_daVo;
import com.dla.daisseo.service.MemberService;
import com.dla.daisseo.utills.BCrypt;


@Controller
@RequestMapping("/member")
public class LoginController {
	

	
	@Autowired
	private MemberService memberservice;
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String toLoginView(Model model) throws Exception{
		
		model.addAttribute("user", new Member_daVo());
		
		return "/Member/Login";
	} 
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String onSubmit(@ModelAttribute("user")@Valid Member_daVo memberdavo, BindingResult result, Model model, HttpServletRequest request) throws Exception{
		

		HttpSession session = request.getSession();		

		if (result.hasFieldErrors("mem_id") || result.hasFieldErrors("mem_pwd")) {
			model.addAllAttributes(result.getModel());
			return "Member/Login";
		}
		
			Member_daVo loginUser = this.memberservice.getMember(memberdavo.getMem_id());
			
			if(loginUser == null) {
				model.addAttribute("errCode",1);
				return "/Member/Login";
			}				
			
			if(BCrypt.checkpw(memberdavo.getMem_pwd(), loginUser.getMem_pwd())) {
			model.addAttribute("loginUser", loginUser);
			model.addAttribute("errCode", 3);			
				
				
				if(memberdavo.getMem_id().equals("admin")) {
					model.addAttribute("errCode", 4);
					}
				
				String mem_id = loginUser.getMem_id();
				int gra_num = loginUser.getGra_num();
				String mem_name = loginUser.getMem_name();
				String myle_num = loginUser.getMyle_num();
				int mem_cash = loginUser.getMem_cash();
				
				
						session.setAttribute("gra_num", gra_num);
						session.setAttribute("mem_id", mem_id);
						session.setAttribute("myle_num", myle_num);
						session.setAttribute("mem_name", mem_name);
						session.setAttribute("mem_cash", mem_cash);
						
						session.setMaxInactiveInterval(60*60);
						// ���� �ѽð� ����
						// ���Ȱ���
				return "/Member/Login";
			}else {
				model.addAttribute("errCode",2);
				return "/Member/Login";
			}
	}
		
	

	@RequestMapping(value = "/idfind", method = RequestMethod.GET)
	public String toFindIdForm(Model model) throws Exception{
		model.addAttribute("userid", new Member_daVo());
		return "/Member/IDfindform";
	}
	
	@RequestMapping(value = "/idfind", method = RequestMethod.POST)
	public String findIdSubmit(@ModelAttribute("userid") @Valid Member_daVo member_davo, BindingResult result, Model model)throws Exception{
		
		if(result.hasFieldErrors("mem_name") || result.hasFieldErrors("mem_email")) {
			model.addAllAttributes(result.getModel());
			return "/Member/IDfindform";
		}	
			Member_daVo findid = this.memberservice.findId(member_davo);
			if(findid != null) {
			model.addAttribute("findid", findid);
			return "/Member/IDfind";
			}else{
			model.addAttribute("errCode", 1);
			return "/Member/IDfindform";
			}

	}

	@RequestMapping(value = "/Passfind", method = RequestMethod.GET)
	public String toFindPassForm(Model model) throws Exception{
		model.addAttribute("userpass", new Member_daVo());
		return "/Member/Passfindform";
	}

	
	@RequestMapping(value = "/Passfind", method = RequestMethod.POST)
	public String findPassSubmit(@ModelAttribute("userpass")@Valid Member_daVo member_davo, BindingResult result, Model model)throws Exception {
		
		if(result.hasFieldErrors("mem_id") || result.hasFieldErrors("mem_email")) {
			model.addAllAttributes(result.getModel());
			return "/Member/Passfindform";
		}
		
			Member_daVo findpass = this.memberservice.findPwd(member_davo);
			if(findpass != null) {
				return "/Member/Passfind";
				}else {
				model.addAttribute("errCode", 1);
				return "/Member/Passfindform";
				}
			
	}

	@RequestMapping(value = "/updatepass", method = RequestMethod.GET)
	public String upPassonSubmit(@ModelAttribute("userpass") @Valid Member_daVo member_davo, BindingResult result, Model model)throws Exception {
		return "/Member/Passfind";
	}
	
	@RequestMapping(value = "/updatepass", method = RequestMethod.POST)
	public String upPassSubmit(@ModelAttribute("userpass") @Valid Member_daVo member_davo, BindingResult result, Model model)throws Exception {
		
		if(result.hasFieldErrors("mem_id") || result.hasFieldErrors("mem_pwd") || result.hasFieldErrors("mem_pwd2")) {
			model.addAllAttributes(result.getModel());
			return "/Member/Passfind";
		}
						
			member_davo.setMem_pwd(BCrypt.hashpw(member_davo.getMem_pwd(), BCrypt.gensalt(12)));
			// ��й�ȣ ������ �н����� ��ȣȭ �κ�

			int updatepass = this.memberservice.pwdUpdate(member_davo);
			if(updatepass != 0) {
				return "redirect:login";
			}else {
				model.addAttribute("errCode", 1);
				return "/Member/passfind";
				}
	}
	
	//�α׾ƿ�
	 @RequestMapping("/logout")
	    public ModelAndView logout(HttpSession session)throws Exception {
	        session.invalidate();
	        ModelAndView mv = new ModelAndView("redirect:/");
	        return mv;
	    }
}